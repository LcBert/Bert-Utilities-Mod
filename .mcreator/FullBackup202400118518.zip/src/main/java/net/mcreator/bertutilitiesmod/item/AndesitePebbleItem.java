
package net.mcreator.bertutilitiesmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AndesitePebbleItem extends Item {
	public AndesitePebbleItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
